<?php
include_once '../../../API/config.php';
require_once $path . '/includes/integrations/constant_contact/cc_helper.php';
$iDevCC = new IdevConstantContactUtil();
$cc_ret = '';
if ( isset($_GET['code']) || isset($_GET['error']) ) {
    $cc_ret = $iDevCC->authorize();
}
if($cc_ret == '') {
    
}

