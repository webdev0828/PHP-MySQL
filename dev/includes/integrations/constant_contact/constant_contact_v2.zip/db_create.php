<?php
include_once '../../../API/config.php';

try {
    
    $query = "CREATE TABLE IF NOT EXISTS `idevaff_newsletter_addons` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `meta_key` varchar(255) DEFAULT NULL,
        `meta_value` longtext,
        PRIMARY KEY (`id`),
        UNIQUE KEY `meta_key` (`meta_key`)
      ) DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;";

    $db->query($query);
    
} catch (Exception $ex) {
    echo $ex->getMessage() . '<br>';
}

//$query = "delete from `idevaff_newsletter_addons` where meta_key='constant_contact' limit 1";
//$db->query($query);

try {
    //CONSUMER_SECRET
    $data = array (
        'enabled' => 0,
        'api_key' => '4urscaqkxxkjn7ssnpm24kb5',
        'consumer_secret' => 'SArqAy4PVQGRutg9gy976YqT',
        'access_token' => '',
        'redirect_uri' => '',
        'list_ids' => array()
    );

    $data = serialize($data);
    $query = "insert into `idevaff_newsletter_addons` (meta_key,meta_value) values('constant_contact','$data')";
    //$query = "update `idevaff_newsletter_addons` set meta_value='$data' where meta_key='aweber'";
    $db->query($query);
    
} catch (Exception $ex) {
    //echo $ex->getMessage() . '<br>';
}


try {
    $query = $db->query("SELECT * FROM `idevaff_newsletter_addons` WHERE meta_key='constant_contact'");
    $query->setFetchMode(PDO::FETCH_ASSOC);
    $getaweber = $query->fetch();
    $getaweber['meta_value'] = unserialize($getaweber['meta_value']);
    echo "<pre>"; print_r($getaweber); echo "</pre>";
    
} catch (Exception $ex) {
     echo $ex->getMessage() . '<br>';
}
?>